import XCTest

final class Q2UITests: XCTestCase {
    let message = "Hello Cybersecurity for mobile platforms! From 14502278"

    private func save(_ name: String) {
        let shot = XCUIScreen.main.screenshot()
        let attachment = XCTAttachment(screenshot: shot)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
        if let dir = ProcessInfo.processInfo.environment["SCREENSHOT_DIR"] {
            let url = URL(fileURLWithPath: dir).appendingPathComponent(name + ".png")
            try? shot.pngRepresentation.write(to: url)
        }
    }

    func testEncryptDecrypt() throws {
        let app = XCUIApplication()
        app.launch()

        let field = app.textFields["messageField"]
        XCTAssertTrue(field.waitForExistence(timeout: 15))
        field.tap()
        field.typeText(message + "\n")   // return key dismisses keyboard

        // Encrypt
        app.buttons["Encrypt"].tap()
        XCTAssertTrue(app.staticTexts["encryptedText"].waitForExistence(timeout: 10))
        sleep(2)
        save("Q2_2_encrypt")

        // Decrypt
        app.buttons["Decrypt"].tap()
        let decrypted = app.staticTexts["decryptedText"]
        XCTAssertTrue(decrypted.waitForExistence(timeout: 10))
        sleep(2)
        XCTAssertEqual(decrypted.label, message)
        save("Q2_3_decrypt")

        // Extra screenshot scrolled down (in case the screen is cut off)
        app.swipeUp()
        sleep(1)
        save("Q2_3_decrypt_scrolled")
    }
}
